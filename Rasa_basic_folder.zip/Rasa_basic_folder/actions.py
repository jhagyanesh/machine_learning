from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_core.actions.action import Action
from rasa_core.events import SlotSet, AllSlotsReset, Restarted
import pandas as pd
import zomatopy
import json
from rasa_core.actions.forms import BooleanFormField, EntityFormField, FormAction, FreeTextFormField
from flask_mail_check import send_email
import pdb


class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_restaurant'
		
	def run(self, dispatcher, tracker, domain):
		#pdb.set_trace()
		config={ "user_key":"b8dd255398eadc56dc0033f46856db5b"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')
		location_detail=zomato.get_location(loc, 1)
		location_json = json.loads(location_detail)
		location_results = len(location_json['location_suggestions'])
		lat=location_json["location_suggestions"][0]["latitude"]
		lon=location_json["location_suggestions"][0]["longitude"]
		city_id=location_json["location_suggestions"][0]["city_id"]
		cuisines_dict={'american': 1,'chinese': 25, 'north indian': 50, 'italian': 55, 'mexican': 73, 'south indian': 85}
			 
			
		list1 = [0,20,40,60,80]
		d = []
		df = pd.DataFrame()
		for i in list1:
			results = zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), limit=i)
			d1 = json.loads(results)
			d = d1['restaurants']
			df1 = pd.DataFrame([{'restaurant_name': x['restaurant']['name'], 'restaurant_rating': x['restaurant']['user_rating']['aggregate_rating'],
				'restaurant_address': x['restaurant']['location']['address'],'budget_for2people': x['restaurant']['average_cost_for_two'],
				'restaurant_photo': x['restaurant']['featured_image'], 'restaurant_url': x['restaurant']['url'] } for x in d])
			df = df.append(df1)

		def budget_group(row):
			if row['budget_for2people'] <300 :
				return 'lesser than 300'
			elif 300 <= row['budget_for2people'] <700 :
				return 'between 300 to 700'
			else:
				return 'more than 700'

		df['budget'] = df.apply(lambda row: budget_group (row),axis=1)
			#sorting by review & filter by budget
		restaurant_df = df[(df.budget == price)]
		restaurant_df = restaurant_df.sort_values(['restaurant_rating'], ascending=0)
		global restaurants

		restaurants = restaurant_df;
		top5 = restaurants.head(5) 
		
		# top 5 results to display
		if len(top5)>0:
			response = 'Showing you top results:' + "\n"
			for index, row in top5.iterrows():
				response = response + str(row["restaurant_name"]) + ' (rated ' + row['restaurant_rating'] + ') in ' + row['restaurant_address'] + ' and the average budget for two people ' + str(row['budget_for2people'])+"\n"
			response = response + "\nShould i mail you the details"

		else:
			response = 'No restaurants found' 

		dispatcher.utter_message(str(response))
		
class ActionLocationValidation(Action):
	def name(self):
		return 'action_check_location'
	
	def run(self, dispatcher, tracker, domain):
		city_dict = ['Ahmedabad','Bangalore','Chennai','Delhi','Hyderabad','Kolkata','Mumbai','Pune','Agra','Ajmer',
		'Aligarh','Allahabad','Amravati','Amritsar','Asansol','Aurangabad','Bareilly','Belgaum','Bhavnagar','Bhiwandi',
		'Bhopal','Bhubaneswar','Bikaner','Bokaro Steel City','Chandigarh','Coimbatore','Cuttack','Dehradun','Dhanbad',
		'Durg-Bhilai Nagar','Durgapur','Erode','Faridabad','Firozabad','Ghaziabad','Gorakhpur','Gulbarga','Guntur',
		'Gurgaon','Guwahati‚ Gwalior','Hubli-Dharwad','Indore','Jabalpur','Jaipur','Jalandhar','Jammu','Jamnagar','Jamshedpur',
		'Jhansi','Jodhpur','Kannur','Kanpur','Kakinada','Kochi','Kottayam','Kolhapur','Kollam','Kota','Kozhikode','Kurnool',
		'Lucknow','Ludhiana','Madurai','Malappuram','Mathura','Goa','Mangalore','Meerut','Moradabad','Mysore','Nagpur','Nanded','Nashik',
		'Nellore','Noida','Palakkad','Patna','Pondicherry','Raipur','Rajkot','Rajahmundry','Ranchi','Rourkela','Salem','Sangli','Siliguri',
		'Solapur','Srinagar','Sultanpur','Surat','Thiruvananthapuram','Thrissur','Tiruchirappalli','Tirunelveli','Tiruppur','Ujjain','Vijayapura',
		'Vadodara','Varanasi','Vasai-Virar City','Vijayawada','Visakhapatnam','Warangal']

		city_dict = [x.lower() for x in city_dict]
		location_detail=zomato.get_location(loc, 1)
		location_json = json.loads(location_detail)
		location_results = len(location_json['location_suggestions'])
		check = ""
		if location_results ==0:
			check = {'location_f' : 'notfound', 'location_new' : None}
		elif loc.lower() not in city_dict:
			check = {'location_f' : 'tier3', 'location_new' : None}
		else:
			check = {'location_f' : 'found', 'location_new' : loc}
		return [SlotSet('location',check['location_new']), SlotSet('location_found',check['location_f'])]
			
class SendMail(Action):
	def name(self):
		return 'email_restaurant_details'
		
	def run(self, dispatcher, tracker, domain):
		#pdb.set_trace()
		recipient = tracker.get_slot('email')

		top10 = restaurants.head(10)
		print("got this correct email is {}".format(recipient))
		send_email(recipient, top10)

		dispatcher.utter_message("Have a great day!")
