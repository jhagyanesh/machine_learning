## Generated Story -3511593075953809027
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_validate_location
    - utter_not_serviceable
    - utter_goodbye
    - action_reset_slot
    - reset_slots
    - export

## Generated Story -4535200731671229910
* 
    - export

