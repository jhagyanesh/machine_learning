
def Config():
	gmail_user = 'upgrad.batch7@gmail.com' # Gmail Username
	gmail_pwd = 'upgrad@2019' #Gmail Password
	gmail_config = (gmail_user, gmail_pwd)
	return gmail_config