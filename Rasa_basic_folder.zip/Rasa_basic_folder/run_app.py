from rasa_core.channels import HttpInputChannel
from rasa_core.agent import Agent
from rasa_core.interpreter import RasaNLUInterpreter
from rasa_slack_connector import SlackInput


nlu_interpreter = RasaNLUInterpreter('./models/nlu/default/restaurantnlu')
agent = Agent.load('./models/dialogue', interpreter = nlu_interpreter)

input_channel = SlackInput('xoxp-791759437648-791757947669-788932811122-2559fa24c9ed95a3b69e427a74695603', #app verification token
							'xoxb-791759437648-803923927222-nths0PnxyB0mbJIVJXyDONFa', # bot verification token
							'Y8zEzNwFW1lse75SI5jFnIFc', # slack verification token
							True)

agent.handle_channel(HttpInputChannel(5004, '/', input_channel))